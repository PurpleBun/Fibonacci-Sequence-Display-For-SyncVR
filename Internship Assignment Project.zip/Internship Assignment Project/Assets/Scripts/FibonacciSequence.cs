using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FibonacciSequence : MonoBehaviour
{
    long valueA;
    long valueB;
    long storeVal;
    RaycastHit hitInfo;
    Ray ray;
    Camera mainCamera;
    public GameObject selectedObject;
    bool isHit;
    GameObject textField;
    string valueText;
    AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {
        valueA = 0;
        valueB = 1;
        storeVal = 0;
        mainCamera = Camera.main;
        textField = GameObject.FindGameObjectWithTag("UserInterface");
        valueText = textField.GetComponent<Text>().text;
        audioSource = GameObject.FindGameObjectWithTag("Audio").GetComponent<AudioSource>();            //The audio clip that you find in this project was downloaded from https://www.zapsplat.com/sound-effect-category/button-clicks/page/2/. The original clip is called "Organic button click, good for apps, games, UI, software etc 5". I do not own this audio clip.
        print(audioSource);


    }

    // Update is called once per frame
    void Update()
    {
#if UNITY_STANDALONE_WIN
        if (Input.GetMouseButtonDown(0))
        {
            ray = mainCamera.ScreenPointToRay(Input.mousePosition);
            isHit = Physics.Raycast(ray, out hitInfo, 1000);
            if (isHit == true)
            {
                selectedObject = hitInfo.transform.gameObject;
                if (selectedObject.tag == "Button")
                {                    
                    valueText = DoTheFibonacci().ToString();
                    print(valueText);
                    textField.GetComponent<Text>().text = valueText;
                    audioSource.Play();
                    selectedObject.gameObject.GetComponent<Animator>().SetTrigger("IsClicked");
                    StartCoroutine(ResetsTrigger());
                }
            }
        }
#endif

        if (Input.touchCount > 0 && Input.touches[0].phase == TouchPhase.Began)
        {
            ray = mainCamera.ScreenPointToRay(Input.touches[0].position);
            isHit = Physics.Raycast(ray, out hitInfo, 1000);
            if (isHit == true)
            {
                selectedObject = hitInfo.transform.gameObject;
                if (selectedObject.tag == "Button")
                {
                    valueText = DoTheFibonacci().ToString();
                    print(valueText);
                    textField.GetComponent<Text>().text = valueText;
                    audioSource.Play();
                    selectedObject.gameObject.GetComponent<Animator>().SetTrigger("IsClicked");
                    StartCoroutine(ResetsTrigger());
                }
            }
        }
    }

    long DoTheFibonacci()
    {
        storeVal = valueA + valueB;
        valueB = valueA;        
        valueA = storeVal;
        return storeVal;
    }

    IEnumerator ResetsTrigger()
    {
        yield return new WaitForSecondsRealtime(0.5f);
        selectedObject.gameObject.GetComponent<Animator>().ResetTrigger("IsClicked");
    }
}
